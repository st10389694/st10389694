/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import javax.swing.JOptionPane;
/**
 *
 * @author Olebogeng Lekalakala
 */
public class Task {
     private String nameOfTask;
    private int taskNumber;
    private String taskDescription;
    private String developerDetails;
    private int taskDuration;
    private String taskID;
    private String taskStatus;
    private String selectTaskStatus;

    public Task(String taskName, int taskNumber, String taskDescription, String developerDetails, int taskDuration) {
        this.nameOfTask = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerDetails = developerDetails;
        this.taskDuration = taskDuration;
        this.taskID = createTaskID();
        this.taskStatus = "To Do";
        
    }

   
  

    

    public boolean checkTaskDescription() {
        return taskDescription.length() <= 50;
    }

    public String createTaskID() {
        String firstTwoLetters = nameOfTask.substring(0, 2);
        String lastThreeLetters = developerDetails.substring(developerDetails.length() - 3);
        return firstTwoLetters.toUpperCase() + ":" + taskNumber + ":" + lastThreeLetters.toUpperCase();
    }
    
    

    public String printTaskDetails() {
        EasyKanban eK = new EasyKanban();
        return "Task Status: " + taskStatus + "\n" +
               "Developer Details: " + developerDetails + "\n" +
               "Task Number: " + taskNumber + "\n" +
               "Task Name: " + nameOfTask + "\n" +
               "Task Description: " + taskDescription + "\n" +
               "Task ID: " + taskID + "\n" +
               "Task Duration: " + taskDuration;
    }

    public int getTaskDuration() {
        return taskDuration;
    }
 
    
}
