
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Olebogeng Lekalakala
 */
public class EasyKanban {
    public static void main(String[] args) {
        // TODO code application logic here
        
       
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        int choose;
        do {
            choose = Integer.parseInt(JOptionPane.showInputDialog(
                    "Choose an option:\n" +
                    "1) Add tasks\n" +
                    "2) Show report\n" +
                    "3) Quit"
            ));

  switch (choose) {
    case 1:
    int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you want to enter:"));

    int totalHours = 0;
    for (int i = 0; i < numTasks; i++) {
    String taskName = JOptionPane.showInputDialog("Enter the task name:");
    String taskDescription = JOptionPane.showInputDialog("Enter the task description (max 50 characters):");
    String developerDetails = JOptionPane.showInputDialog("Enter the developer details:");
    int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the task duration in hours:"));

    Task task = new Task(taskName, i, taskDescription, developerDetails, taskDuration);
    if (!task.checkTaskDescription()) {
    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
    i--;
    continue;
    }

    totalHours += task.getTaskDuration();

    JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

    JOptionPane.showMessageDialog(null, "Total combined hours of all tasks: " + totalHours);
    break;

    case 2:
     TaskManagement app = new TaskManagement ();
        app.populateArrays();

        boolean exit = false;
        while (!exit) {
            String choice = JOptionPane.showInputDialog(null,
                    "Select an option:\n"
                            + "1. Display tasks with status 'Done'\n"
                            + "2. Display the developer and duration of the task with the longest duration\n"
                            + "3. Search for a task by name\n"
                            + "4. Search for tasks assigned to a developer\n"
                            + "5. Delete a task\n"
                            + "6. Display full task report\n"
                            + "7. Exit",
                    "Task Management", JOptionPane.QUESTION_MESSAGE);

            if (choice != null) {
                switch (choice) {
                    case "1":
                        app.displayDoneTasks();
                        break;
                    case "2":
                        app.displayLongestTask();
                        break;
                    case "3":
                        String taskName = JOptionPane.showInputDialog(null, "Enter the task name:");
                        if (taskName != null) {
                            app.searchTaskByName(taskName);
                        }
                        break;
                    case "4":
                        String developer = JOptionPane.showInputDialog(null, "Enter the developer name:");
                        if (developer != null) {
                            app.searchTasksByDeveloper(developer);
                        }
                        break;
                    case "5":
                        String taskToDelete = JOptionPane.showInputDialog(null, "Enter the task name to delete:");
                        if (taskToDelete != null) {
                            app.deleteTask(taskToDelete);
                        }
                        break;
                    case "6":
                        app.displayFullReport();
                        break;
                    case "7":
                        exit = true;
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid choice. Please try again.");
                        break;
                }
            } else {
                exit = true;
            }
        }
    break;

    case 3:
    JOptionPane.showMessageDialog(null, "Goodbye!");
    break;

    default:
    JOptionPane.showMessageDialog(null, "Invalid choice");
    break;
            }
        } while (choose != 3);
    }
    
}
