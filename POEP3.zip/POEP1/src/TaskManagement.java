/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import javax.swing.JOptionPane;
/**
 *
 * @author Olebogeng Lekalakala
 */

public class TaskManagement {
    private String[] developers;
    private String[] taskNames;
    private int[] taskIDs;
    private int[] taskDurations;
    private String[] taskStatuses;

    public TaskManagement() {
        developers = new String[0];
        taskNames = new String[0];
        taskIDs = new int[0];
        taskDurations = new int[0];
        taskStatuses = new String[0];
    }

    public void populateArrays() {
        int numOfTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks:"));

        developers = new String[numOfTasks];
        taskNames = new String[numOfTasks];
        taskIDs = new int[numOfTasks];
        taskDurations = new int[numOfTasks];
        taskStatuses = new String[numOfTasks];

        for (int i = 0; i < numOfTasks; i++) {
            developers[i] = JOptionPane.showInputDialog("Enter the developer for task #" + (i + 1));
            taskNames[i] = JOptionPane.showInputDialog("Enter the name of task #" + (i + 1));
            taskIDs[i] = i + 1;
            taskDurations[i] = Integer.parseInt(JOptionPane.showInputDialog("Enter the duration for task #" + (i + 1)));
            taskStatuses[i] = JOptionPane.showInputDialog("Enter the status for task #" + (i + 1));
        }
    }

    public void displayDoneTasks() {
        StringBuilder result = new StringBuilder();
        result.append("Tasks with status 'done':\n");

        for (int i = 0; i < taskStatuses.length; i++) {
            if (taskStatuses[i].equalsIgnoreCase("done")) {
                result.append("Developer: ").append(developers[i])
                        .append(", Task Name: ").append(taskNames[i])
                        .append(", Task Duration: ").append(taskDurations[i])
                        .append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    public void displayLongestTask() {
        int maxDuration = 0;
        String longestDurationDeveloper = "";

        for (int i = 0; i < taskDurations.length; i++) {
            if (taskDurations[i] > maxDuration) {
                maxDuration = taskDurations[i];
                longestDurationDeveloper = developers[i];
            }
        }

        JOptionPane.showMessageDialog(null, "Developer with longest duration: " + longestDurationDeveloper
                + ", Duration: " + maxDuration);
    }

    public void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog("Enter the task name to search:");

        StringBuilder result = new StringBuilder();
        result.append("Tasks with name '").append(taskName).append("':\n");

        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskName)) {
                result.append("Task Name: ").append(taskNames[i])
                        .append(", Developer: ").append(developers[i])
                        .append(", Task Status: ").append(taskStatuses[i])
                        .append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    public void searchTasksByDeveloper() {
        String developer = JOptionPane.showInputDialog("Enter the developer name to search tasks:");

        StringBuilder result = new StringBuilder();
        result.append("Tasks assigned to '").append(developer).append("':\n");

        for (int i = 0; i < developers.length; i++) {
            if (developers[i].equalsIgnoreCase(developer)) {
                result.append("Task Name: ").append(taskNames[i])
                        .append(", Task Status: ").append(taskStatuses[i])
                        .append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    public void deleteTask() {
        String taskToDelete = JOptionPane.showInputDialog("Enter the task name to delete:");

        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskToDelete)) {
                developers[i] = "";
                taskNames[i] = "";
                taskIDs[i] = 0;
                taskDurations[i] = 0;
                taskStatuses[i] = "";
                JOptionPane.showMessageDialog(null, "Task '" + taskToDelete + "' deleted successfully.");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Task '" + taskToDelete + "' not found.");
    }

    public void displayFullReport() {
        StringBuilder result = new StringBuilder();
        result.append("Task Report:\n");

        for (int i = 0; i < taskNames.length; i++) {
            result.append("Task ID: ").append(taskIDs[i])
                    .append(", Task Name: ").append(taskNames[i])
                    .append(", Developer: ").append(developers[i])
                    .append(", Duration: ").append(taskDurations[i])
                    .append(", Status: ").append(taskStatuses[i])
                    .append("\n");
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    public static void main(String[] args) {
        EasyKanban easy = new EasyKanban();
        TaskManagement app = new TaskManagement();
        app.populateArrays();

        
        app.displayDoneTasks();

        
        app.displayLongestTask();

        
        app.searchTaskByName();

        
        app.searchTasksByDeveloper();

        
        app.deleteTask();

        
        app.displayFullReport();
    }

    void searchTaskByName(String taskName) {
         StringBuilder result = new StringBuilder();
        result.append("Tasks with name '").append(taskName).append("':\n");

        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskName)) {
                result.append("Task Name: ").append(taskNames[i])
                        .append(", Developer: ").append(developers[i])
                        .append(", Task Status: ").append(taskStatuses[i])
                        .append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    void searchTasksByDeveloper(String developer) {
        StringBuilder result = new StringBuilder();
        result.append("Tasks assigned to '").append(developer).append("':\n");

        for (int i = 0; i < developers.length; i++) {
            if (developers[i].equalsIgnoreCase(developer)) {
                result.append("Task Name: ").append(taskNames[i])
                        .append(", Task Status: ").append(taskStatuses[i])
                        .append("\n");
            }
        }

        JOptionPane.showMessageDialog(null, result.toString());
    }

    void deleteTask(String taskToDelete) {
        for (int i = 0; i < taskNames.length; i++) {
            if (taskNames[i].equalsIgnoreCase(taskToDelete)) {
                developers[i] = "";
                taskNames[i] = "";
                taskIDs[i] = 0;
                taskDurations[i] = 0;
                taskStatuses[i] = "";
                JOptionPane.showMessageDialog(null, "Task '" + taskToDelete + "' deleted successfully.");
                return;
            }
        }

        JOptionPane.showMessageDialog(null, "Task '" + taskToDelete + "' not found.");
    }
        
    }

    

    

