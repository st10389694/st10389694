/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Olebogeng Lekalakala
 */
public class TaskManagementTest {
    
    public TaskManagementTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of addTask method, of class TaskManagement.
     */
    @Test
    public void testAddTask() {
        System.out.println("addTask");
        String developer = "";
        String taskName = "";
        int duration = 0;
        String status = "";
        int developerDetails = 0;
        int nameOfTask = 0;
        int taskID = 0;
        int taskDuration = 0;
        int taskStatus = 0;
        TaskManagement instance = new TaskManagement();
      // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayDoneTasks method, of class TaskManagement.
     */
    @Test
    public void testDisplayDoneTasks() {
        System.out.println("displayDoneTasks");
        TaskManagement instance = new TaskManagement();
        instance.displayDoneTasks();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of displayLongestTask method, of class TaskManagement.
     */
    @Test
    public void testDisplayLongestTask() {
        TaskManagementTest app = new TaskManagementTest();
        String expectedOutput = "Glenda Oberholzer, 11";
        String actualOutput = app.displayLongestTask();

        Assertions.assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test of searchTaskByName method, of class TaskManagement.
     */
    @Test
    public void testSearchTaskByName() {
      TaskManagementTest app = new TaskManagementTest();
        String expectedOutput = "Mike Smith, Create Login";
        String actualOutput = app.searchTaskByName("Create Login");

        Assertions.assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test of searchTasksByDeveloper method, of class TaskManagement.
     */
    @Test
    public void testSearchTasksByDeveloper() {
        TaskManagementTest app = new TaskManagementTest();
        String expectedOutput = "Create Reports";
        String actualOutput = app.searchTasksByDeveloper("Samantha Paulson");

        Assertions.assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test of deleteTask method, of class TaskManagement.
     */
    @Test
    public void testDeleteTask() {
        TaskManagementTest app = new TaskManagementTest();
        String taskToDelete = "Create Reports";
        String expectedOutput = "Entry \"Create Reports\" successfully deleted";
        String actualOutput = app.deleteTask(taskToDelete);

        Assertions.assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test of displayFullReport method, of class TaskManagement.
     */
    @Test
    public void testDisplayFullReport() {
       TaskManagementTest app = new TaskManagementTest();
        String expectedOutput = "<expected report output>";
        String actualOutput = app.displayFullReport();

        Assertions.assertEquals(expectedOutput, actualOutput);
    }

    /**
     * Test of main method, of class TaskManagement.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        TaskManagement.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    private String displayFullReport() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String deleteTask(String taskToDelete) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String searchTasksByDeveloper(String samantha_Paulson) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String searchTaskByName(String create_Login) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private String displayLongestTask() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    /**
     * Test of populateArrays method, of class TaskManagement.
     */
    @Test
    public void testPopulateArrays() {
        System.out.println("populateArrays");
        TaskManagement instance = new TaskManagement();
        instance.populateArrays();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTaskByName method, of class TaskManagement.
     */
    @Test
    public void testSearchTaskByName_0args() {
        System.out.println("searchTaskByName");
        TaskManagement instance = new TaskManagement();
        instance.searchTaskByName();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTasksByDeveloper method, of class TaskManagement.
     */
    @Test
    public void testSearchTasksByDeveloper_0args() {
        System.out.println("searchTasksByDeveloper");
        TaskManagement instance = new TaskManagement();
        instance.searchTasksByDeveloper();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTask method, of class TaskManagement.
     */
    @Test
    public void testDeleteTask_0args() {
        System.out.println("deleteTask");
        TaskManagement instance = new TaskManagement();
        instance.deleteTask();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTaskByName method, of class TaskManagement.
     */
    @Test
    public void testSearchTaskByName_String() {
        System.out.println("searchTaskByName");
        String taskName = "";
        TaskManagement instance = new TaskManagement();
        instance.searchTaskByName(taskName);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of searchTasksByDeveloper method, of class TaskManagement.
     */
    @Test
    public void testSearchTasksByDeveloper_String() {
        System.out.println("searchTasksByDeveloper");
        String developer = "";
        TaskManagement instance = new TaskManagement();
        instance.searchTasksByDeveloper(developer);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deleteTask method, of class TaskManagement.
     */
    @Test
    public void testDeleteTask_String() {
        System.out.println("deleteTask");
        String taskToDelete = "";
        TaskManagement instance = new TaskManagement();
        instance.deleteTask(taskToDelete);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
