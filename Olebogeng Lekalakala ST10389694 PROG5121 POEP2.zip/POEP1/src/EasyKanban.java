
import javax.swing.JOptionPane;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Olebogeng Lekalakala
 */
public class EasyKanban {
    public static void main(String[] args) {
        // TODO code application logic here
        
       
        JOptionPane.showMessageDialog(null, "Welcome to EasyKanban");

        int choose;
        do {
            choose = Integer.parseInt(JOptionPane.showInputDialog(
                    "Choose an option:\n" +
                    "1) Add tasks\n" +
                    "2) Show report\n" +
                    "3) Quit"
            ));

  switch (choose) {
    case 1:
    int numTasks = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of tasks you want to enter:"));

    int totalHours = 0;
    for (int i = 0; i < numTasks; i++) {
    String taskName = JOptionPane.showInputDialog("Enter the task name:");
    String taskDescription = JOptionPane.showInputDialog("Enter the task description (max 50 characters):");
    String developerDetails = JOptionPane.showInputDialog("Enter the developer details:");
    int taskDuration = Integer.parseInt(JOptionPane.showInputDialog("Enter the task duration in hours:"));

    Task task = new Task(taskName, i, taskDescription, developerDetails, taskDuration);
    if (!task.checkTaskDescription()) {
    JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters");
    i--;
    continue;
    }

    totalHours += task.getTaskDuration();

    JOptionPane.showMessageDialog(null, task.printTaskDetails());
        }

    JOptionPane.showMessageDialog(null, "Total combined hours of all tasks: " + totalHours);
    break;

    case 2:
    JOptionPane.showMessageDialog(null, "Coming Soon");
    break;

    case 3:
    JOptionPane.showMessageDialog(null, "Goodbye!");
    break;

    default:
    JOptionPane.showMessageDialog(null, "Invalid choice");
    break;
            }
        } while (choose != 3);
    }
    
}
